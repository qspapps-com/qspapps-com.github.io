#!/usr/bin/env python3
"""
Extract photos and videos from Google Takeout zip files or folders to the Fotoloka import directory.

Usage:
    python3 extract_takeout_media.py <source_dir> <dest_dir> [--dry-run] [--flatten]
    python3 extract_takeout_media.py --source-dir <source_dir> --dest-dir <dest_dir> [--dry-run] [--flatten]
"""

import os
import sys
import time
import glob
import shutil
import zipfile
import argparse
import datetime
from collections import Counter

# Supported media extensions
PHOTO_EXTENSIONS = {
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp', '.heic', '.heif'
}
VIDEO_EXTENSIONS = {
    '.mp4', '.mov', '.avi', '.mpg', '.mpeg', '.m4v', '.3gp', '.mkv', '.flv', '.wmv', '.webm', '.mp'
}
MEDIA_EXTENSIONS = PHOTO_EXTENSIONS | VIDEO_EXTENSIONS

# Logging setup
log_file = None

def init_logging(log_dir):
    global log_file
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(log_dir, f"extract_takeout_media_{timestamp}.log")
    try:
        log_file = open(log_path, "w", encoding="utf-8")
    except Exception as e:
        print(f"Warning: Could not open log file {log_path}: {e}")
    return log_path

def log(msg, to_stdout=True):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted = f"[{ts}] {msg}"
    if to_stdout:
        print(formatted)
    if log_file:
        log_file.write(formatted + "\n")
        log_file.flush()

def format_bytes(size):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"

def get_clean_relative_path(member_name, flatten=False, convert_mp=True):
    """
    Strips 'Takeout/Google Photos/', 'Google Photos/', or 'Takeout/' prefix from member name.
    If flatten is True, returns only the filename.
    Optionally converts .mp extension (Pixel motion photos) to .mp4 so the scanner indexes it.
    """
    clean_name = member_name.replace('\\', '/')

    takeout_gp = "Takeout/Google Photos/"
    gp = "Google Photos/"
    takeout = "Takeout/"

    if takeout_gp in clean_name:
        clean_name = clean_name[clean_name.find(takeout_gp) + len(takeout_gp):]
    elif gp in clean_name:
        clean_name = clean_name[clean_name.find(gp) + len(gp):]
    elif takeout in clean_name:
        clean_name = clean_name[clean_name.find(takeout) + len(takeout):]

    clean_name = clean_name.lstrip('/')

    if flatten:
        clean_name = os.path.basename(clean_name)

    base, ext = os.path.splitext(clean_name)
    if convert_mp and ext.lower() == '.mp':
        clean_name = base + '.mp4'

    return clean_name

def resolve_destination_path(dest_dir, rel_path, expected_size=None):
    """
    Resolves the destination file path.
    - If file doesn't exist: return (target_path, False) [proceed to copy]
    - If file exists (same filename): return (target_path, True) [skip copy]
    """
    target_path = os.path.join(dest_dir, rel_path)
    if os.path.exists(target_path):
        return target_path, True
    return target_path, False

def extract_from_zip(zip_path, dest_dir, args, stats, start_time):
    """
    Extracts media files from a single zip archive.
    """
    zip_name = os.path.basename(zip_path)
    zip_size = os.path.getsize(zip_path)
    log(f"Processing archive: {zip_name} ({format_bytes(zip_size)})")

    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            infolist = zf.infolist()
            media_members = []
            for info in infolist:
                if info.is_dir():
                    continue
                ext = os.path.splitext(info.filename)[1].lower()
                if ext in MEDIA_EXTENSIONS:
                    media_members.append(info)

            log(f"  Found {len(media_members)} media file(s) in {zip_name}")

            for member in media_members:
                stats['total_media_found'] += 1
                ext = os.path.splitext(member.filename)[1].lower()
                stats['extension_counts'][ext] += 1

                rel_path = get_clean_relative_path(
                    member.filename,
                    flatten=args.flatten,
                    convert_mp=not args.keep_mp_extension
                )

                target_path, is_existing = resolve_destination_path(dest_dir, rel_path)
                if is_existing:
                    stats['skipped_existing'] += 1
                    continue

                if not args.dry_run:
                    try:
                        os.makedirs(os.path.dirname(target_path), exist_ok=True)
                        with zf.open(member) as src_file, open(target_path, 'wb') as dst_file:
                            shutil.copyfileobj(src_file, dst_file, length=1024 * 1024)

                        if member.date_time:
                            try:
                                dt = datetime.datetime(*member.date_time)
                                epoch = dt.timestamp()
                                os.utime(target_path, (epoch, epoch))
                            except Exception:
                                pass

                        stats['extracted'] += 1
                        stats['bytes_extracted'] += member.file_size
                    except Exception as e:
                        stats['errors'] += 1
                        if os.path.exists(target_path) and os.path.getsize(target_path) == 0:
                            try:
                                os.remove(target_path)
                            except Exception:
                                pass
                        log(f"  [ERROR] Failed to extract {member.filename} to {target_path}: {e}")
                else:
                    stats['extracted'] += 1
                    stats['bytes_extracted'] += member.file_size

    except Exception as e:
        stats['errors'] += 1
        log(f"  [ERROR] Failed to open/process archive {zip_name}: {e}")

def copy_file_preserving_mtime(src_path, dst_path):
    """
    Copies file contents and preserves mtime/atime without failing on filesystems
    (like NTFS or FAT over USB) that do not support POSIX/macOS extended attributes or flags.
    """
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    shutil.copyfile(src_path, dst_path)
    try:
        st = os.stat(src_path)
        os.utime(dst_path, (st.st_atime, st.st_mtime))
    except Exception:
        pass

def extract_from_directory(src_dir, dest_dir, args, stats, start_time):
    """
    Scans src_dir for loose media files (excluding dest_dir) and copies them to dest_dir.
    """
    dest_real = os.path.realpath(dest_dir)
    src_real = os.path.realpath(src_dir)
    last_log_time = start_time
    last_logged_count = stats['extracted'] + stats['skipped_existing']

    log(f"Scanning directory tree for media files: {src_dir}")

    for root, dirs, files in os.walk(src_dir):
        # Exclude destination if inside source, and ignore system directories
        dirs[:] = [
            d for d in dirs
            if not d.startswith('.')
            and d not in ('$RECYCLE.BIN', 'System Volume Information')
            and os.path.realpath(os.path.join(root, d)) != dest_real
            and not os.path.realpath(os.path.join(root, d)).startswith(dest_real + os.sep)
        ]

        media_files = []
        for f in files:
            if f.startswith('.'):
                continue
            ext = os.path.splitext(f)[1].lower()
            if ext in MEDIA_EXTENSIONS:
                media_files.append(f)

        if not media_files:
            continue

        rel_dir = os.path.relpath(root, src_dir)
        dir_display = "." if rel_dir == "." else rel_dir
        log(f"  Processing folder: {dir_display} ({len(media_files)} media file(s))")

        for f in media_files:
            src_file_path = os.path.join(root, f)
            try:
                file_size = os.path.getsize(src_file_path)
            except Exception as e:
                stats['errors'] += 1
                log(f"  [ERROR] Cannot read file size for {src_file_path}: {e}")
                continue

            stats['total_media_found'] += 1
            ext = os.path.splitext(f)[1].lower()
            stats['extension_counts'][ext] += 1

            rel_file_path = os.path.relpath(src_file_path, src_dir)
            rel_path = get_clean_relative_path(
                rel_file_path,
                flatten=args.flatten,
                convert_mp=not args.keep_mp_extension
            )

            target_path, is_existing = resolve_destination_path(dest_dir, rel_path)
            if is_existing:
                stats['skipped_existing'] += 1
                continue

            if not args.dry_run:
                try:
                    copy_file_preserving_mtime(src_file_path, target_path)
                    stats['extracted'] += 1
                    stats['bytes_extracted'] += file_size
                except Exception as e:
                    stats['errors'] += 1
                    if os.path.exists(target_path) and os.path.getsize(target_path) == 0:
                        try:
                            os.remove(target_path)
                        except Exception:
                            pass
                    log(f"  [ERROR] Failed to copy {src_file_path} to {target_path}: {e}")
            else:
                stats['extracted'] += 1
                stats['bytes_extracted'] += file_size

            # Periodic progress log (every 500 items or 10 seconds)
            processed_count = stats['extracted'] + stats['skipped_existing']
            now = time.time()
            if processed_count - last_logged_count >= 500 or (now - last_log_time >= 10 and processed_count > last_logged_count):
                last_logged_count = processed_count
                last_log_time = now
                elapsed = now - start_time
                log(f"  Progress: {stats['extracted']} copied ({format_bytes(stats['bytes_extracted'])}), "
                    f"{stats['skipped_existing']} skipped existing, {stats['errors']} errors (elapsed: {elapsed:.1f}s)")

def main():
    parser = argparse.ArgumentParser(
        description="Extract all photos and videos from Google Takeout zip archives or folders into a Fotoloka import directory.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  macOS / Linux:
    python3 extract_takeout_media.py ~/Downloads/Takeout ~/Pictures/FamilyPhotoBackup/import/YourName
    python3 extract_takeout_media.py /Volumes/ExternalDrive/Takeout_20230527 /Volumes/ExternalDrive/import
  Windows:
    python extract_takeout_media.py %USERPROFILE%\\Downloads\\Takeout %USERPROFILE%\\Pictures\\FamilyPhotoBackup\\import\\YourName
        """.strip()
    )
    parser.add_argument(
        "source_dir",
        nargs="?",
        default=None,
        help="Directory containing Google Takeout zip archives or extracted folders"
    )
    parser.add_argument(
        "dest_dir",
        nargs="?",
        default=None,
        help="Destination directory for imported photos (e.g. Pictures/FamilyPhotoBackup/import/<name>)"
    )
    parser.add_argument(
        "--source-dir", "-s",
        dest="opt_source_dir",
        help="Directory containing Google Takeout zip archives or extracted folders (alias for source_dir)"
    )
    parser.add_argument(
        "--dest-dir", "-d",
        dest="opt_dest_dir",
        help="Destination directory for imported photos (alias for dest_dir)"
    )
    parser.add_argument(
        "--log-dir", "-l",
        default=None,
        help="Directory to write execution logs (default: <dest_dir>/logs)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate extraction without writing any files to disk"
    )
    parser.add_argument(
        "--flatten",
        action="store_true",
        help="Extract all files directly to destination root without album/year subdirectories"
    )
    parser.add_argument(
        "--keep-mp-extension",
        action="store_true",
        help="Do not convert .mp extensions to .mp4 (note: server scanner ignores .mp by default)"
    )
    args = parser.parse_args()

    raw_src = args.opt_source_dir or args.source_dir
    raw_dest = args.opt_dest_dir or args.dest_dir

    if not raw_src or not raw_dest:
        parser.error("Both source directory (with Takeout files/folders) and destination directory are required.")

    src_dir = os.path.abspath(os.path.expanduser(raw_src))
    dest_dir = os.path.abspath(os.path.expanduser(raw_dest))
    log_dir = os.path.abspath(os.path.expanduser(args.log_dir)) if args.log_dir else os.path.join(dest_dir, "logs")

    log_path = init_logging(log_dir)
    log("=" * 70)
    log(" Google Takeout Media Extractor")
    log("=" * 70)
    log(f"Source Directory: {src_dir}")
    log(f"Destination Directory: {dest_dir}")
    log(f"Log File: {log_path}")
    log(f"Mode: {'DRY RUN (simulation only)' if args.dry_run else 'LIVE RUN (writing files)'}")
    log(f"Preserve Subdirectories: {not args.flatten}")
    log(f"Convert .mp to .mp4: {not args.keep_mp_extension}")
    log("=" * 70)

    if not os.path.isdir(src_dir):
        log(f"Error: Source directory does not exist: {src_dir}")
        sys.exit(1)

    os.makedirs(dest_dir, exist_ok=True)

    stats = {
        'total_media_found': 0,
        'extracted': 0,
        'skipped_existing': 0,
        'collisions_renamed': 0,
        'bytes_extracted': 0,
        'errors': 0,
        'extension_counts': Counter()
    }

    start_time = time.time()

    # 1. Process zip archives if any exist in source_dir
    zip_files = sorted(glob.glob(os.path.join(src_dir, "*.zip")))
    if zip_files:
        log(f"Found {len(zip_files)} zip file(s) in source directory.\n")
        for idx, zip_path in enumerate(zip_files, start=1):
            log(f"[{idx}/{len(zip_files)}] Archive: {os.path.basename(zip_path)}")
            extract_from_zip(zip_path, dest_dir, args, stats, start_time)
            elapsed = time.time() - start_time
            log(f"  Archive progress: {stats['extracted']} copied ({format_bytes(stats['bytes_extracted'])}), "
                f"{stats['skipped_existing']} skipped existing, {stats['errors']} errors (elapsed: {elapsed:.1f}s)\n")

    # 2. Process loose media files in source_dir tree
    extract_from_directory(src_dir, dest_dir, args, stats, start_time)

    if stats['total_media_found'] == 0:
        log(f"Error: No media files or .zip archives found in {src_dir}")
        sys.exit(1)

    total_elapsed = time.time() - start_time

    log("=" * 70)
    log(" Extraction Complete - Summary")
    log("=" * 70)
    if zip_files:
        log(f"Total zip archives:      {len(zip_files)}")
    log(f"Total media files found: {stats['total_media_found']}")
    log(f"Extracted / Copied:      {stats['extracted']}")
    log(f"Skipped (identical):     {stats['skipped_existing']}")
    log(f"Collisions renamed:      {stats['collisions_renamed']}")
    log(f"Errors encountered:      {stats['errors']}")
    log(f"Total bytes extracted:   {format_bytes(stats['bytes_extracted'])}")
    log(f"Total time elapsed:      {total_elapsed:.1f} seconds ({total_elapsed/60.0:.2f} minutes)")
    log("-" * 70)
    log("Media types extracted:")
    for ext, count in stats['extension_counts'].most_common():
        log(f"  {ext}: {count}")
    log("=" * 70)
    log(f"All logs saved to: {log_path}")

if __name__ == "__main__":
    main()
