@echo off
title FamilyPhotoBackup Server
cd /d "%APPDATA%\FamilyPhotoBackup"

REM Settings - storage location, server password, Smart TV viewer - are read from
REM photobackup.properties in this folder. Edit that file, then run this launcher again.
REM Environment variables set here would override it; none are set on purpose.

start "" javaw -DLOG_FILE="%APPDATA%\FamilyPhotoBackup\server_log.log" -jar photo-backup-server-all.jar
