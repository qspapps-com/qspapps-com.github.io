@echo off
setlocal
::
:: Fotoloka server update & install launcher for Windows.
::
:: Verifies Java 21+ prerequisite and starts the Update-Install wizard.
::
:: Usage:  update-install.bat [options]
::         update-install.bat --cli
::
echo === Fotoloka Windows Server Update and Installer ===

pushd "%~dp0.."
set BUNDLE_ROOT=%CD%
popd
set JAR_SOURCE=%BUNDLE_ROOT%\photo-backup-server-all.jar

:: 1. Java check: Require Java 21 or newer
where java >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo(
    echo ==================================================================
    echo [ERROR] No 'java' found on your PATH.
    echo Fotoloka server requires Java 21 or newer.
    echo(
    echo Please download and install Java 21+ from one of these sites:
    echo   - Eclipse Temurin: https://adoptium.net/
    echo   - Oracle Java:     https://www.oracle.com/java/technologies/downloads/
    echo ==================================================================
    echo(
    pause
    exit /b 1
)

set "JAVA_MAJOR="
set "RAW_VER="
for /f "tokens=3" %%g in ('java -version 2^>^&1 ^| findstr /i "version"') do (
    set "RAW_VER=%%~g"
)
if defined RAW_VER (
    for /f "tokens=1 delims=.-_" %%h in ("%RAW_VER%") do (
        set "JAVA_MAJOR=%%h"
    )
)
if "%JAVA_MAJOR%"=="1" (
    for /f "tokens=2 delims=." %%h in ("%RAW_VER%") do (
        set "JAVA_MAJOR=%%h"
    )
)

if not defined JAVA_MAJOR (
    set "JAVA_MAJOR=0"
)

if %JAVA_MAJOR% lss 21 (
    echo(
    echo ==================================================================
    echo [ERROR] Java %JAVA_MAJOR% detected [%RAW_VER%].
    echo Fotoloka server requires Java 21 or newer.
    echo(
    echo Please download and install Java 21+ from one of these sites:
    echo   - Eclipse Temurin: https://adoptium.net/
    echo   - Oracle Java:     https://www.oracle.com/java/technologies/downloads/
    echo ==================================================================
    echo(
    pause
    exit /b 1
)

if not exist "%JAR_SOURCE%" (
    set "REPO_ROOT=%BUNDLE_ROOT%\.."
    for /f %%i in ('dir /b /s "%REPO_ROOT%\build\libs\photo-backup-server-*-all.jar" 2^>nul') do set "JAR_SOURCE=%%i"
    if not defined JAR_SOURCE if exist "%REPO_ROOT%\gradlew.bat" (
        echo Building server shadow JAR from source...
        pushd "%REPO_ROOT%"
        call gradlew.bat shadowJar
        popd
        for /f %%i in ('dir /b /s "%REPO_ROOT%\build\libs\photo-backup-server-*-all.jar" 2^>nul') do set "JAR_SOURCE=%%i"
    )
)

if not exist "%JAR_SOURCE%" (
    echo [ERROR] photo-backup-server-all.jar is missing from %BUNDLE_ROOT%.
    echo         Extract the entire zip archive or run gradlew.bat shadowJar.
    pause
    exit /b 1
)

:: Clean up any lingering backup (.bak) files in the Windows Startup directory
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\FamilyPhotoBackup*.bak" (
    del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\FamilyPhotoBackup*.bak" >nul 2>&1
)

:: 2. Start update-install wizard
echo Starting Fotoloka Update-Install Wizard...
java -jar "%JAR_SOURCE%" --wizard --bundle-dir "%BUNDLE_ROOT%" %*
