@echo off
setlocal
::
:: Fotoloka server uninstaller for Windows.
::
:: Stops the server and removes the program. Your photo library is left alone: it lives in
:: %USERPROFILE%\Pictures\FamilyPhotoBackup or on your external drive, not here.
::
echo === Fotoloka Windows Server Uninstaller ===

set INSTALL_DIR=%APPDATA%\FamilyPhotoBackup
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

echo Stopping the server (if running)...
taskkill /f /fi "WINDOWTITLE eq FamilyPhotoBackup Server" >nul 2>&1

if exist "%STARTUP_DIR%\FamilyPhotoBackup.bat" (
    echo Removing the startup launcher...
    del /q "%STARTUP_DIR%\FamilyPhotoBackup.bat"
)

if exist "%STARTUP_DIR%\FamilyPhotoBackup.vbs" (
    echo Removing the startup launcher...
    del /q "%STARTUP_DIR%\FamilyPhotoBackup.vbs"
)

if exist "%STARTUP_DIR%\FamilyPhotoBackup*.bak" (
    echo Removing startup backup files...
    del /q "%STARTUP_DIR%\FamilyPhotoBackup*.bak"
)

if exist "%INSTALL_DIR%" (
    echo Removing program files at: %INSTALL_DIR%
    rmdir /s /q "%INSTALL_DIR%"
)

echo.
echo === Uninstall complete ===
echo The server is stopped and will not start again at login.
echo Your photos in %USERPROFILE%\Pictures\FamilyPhotoBackup (or on your external drive)
echo are untouched.
pause
