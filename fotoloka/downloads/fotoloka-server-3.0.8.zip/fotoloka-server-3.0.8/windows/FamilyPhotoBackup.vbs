Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = WshShell.ExpandEnvironmentStrings("%APPDATA%\FamilyPhotoBackup")
WshShell.Run "javaw -DLOG_FILE=""" & WshShell.ExpandEnvironmentStrings("%APPDATA%\FamilyPhotoBackup\server_log.log") & """ -jar photo-backup-server-all.jar", 0, False
