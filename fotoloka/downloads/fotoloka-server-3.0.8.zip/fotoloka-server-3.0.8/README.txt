Fotoloka server
===============

The Fotoloka server turns a Mac, a Windows PC or a Raspberry Pi on your home network
into the place your family's photos live. Phones back up to it over Wi-Fi; any browser
in the house can view the library at http://<that-machine's-ip>:8080/app/.

Nothing here talks to the internet. There is no account and no cloud.


Before you start
----------------

You need a Java runtime, version 21 or newer, on the machine that will hold the photos.

  macOS         brew install --cask temurin@21
                or a .pkg installer from https://adoptium.net
  Windows       https://adoptium.net  (Eclipse Temurin 21, .msi)
  Raspberry Pi  sudo apt update && sudo apt install -y default-jre
  Linux         your distribution's default-jre / java-21-openjdk

Check it with:  java -version

The installers stop with a clear message if Java is missing, so you can install it and
run them again.


Install or Update
-----------------

Unpack this download, open a terminal in the unpacked folder, and run the update-install
script for your platform. It launches the interactive Update-Install UI wizard:

  macOS         chmod +x macos/update-install.sh
                ./macos/update-install.sh
                (or ./macos/update-install.sh --cli for console mode)

  Windows       windows\update-install.bat
                (or windows\update-install.bat --cli for console mode)

  Linux / Pi    chmod +x linux/update-install.sh
                ./linux/update-install.sh
                (or ./linux/update-install.sh --cli for console mode)

The wizard will:
1. Detect whether an existing Fotoloka installation is present and offer Update or Fresh Install.
2. In Fresh Install mode: display default config values with clear explanations and allow customization.
3. In Update mode: display existing config values, warn if changing storage root, and back up old files
   with a .bak extension before overwriting.
4. Copy scripts, binaries, and properties file, start the background service, and verify health.
5. In case of startup error, display the full server log output; otherwise report success and local links.

The server starts immediately and comes back on its own at every login (macOS, Windows)
or boot (Linux). Open http://localhost:8080/ on that machine to confirm it is up.

On Windows, allow Java through the firewall on Private networks when asked. If you say
no, no phone on your Wi-Fi will find the server.


Stop the machine going to sleep
-------------------------------

Read this one. A sleeping laptop answers nothing: the app's status dot goes grey, backups
stall, and it looks exactly like a broken server. It is the most common complaint about
Fotoloka and it is never the software.

The giveaway is that it works while you are sitting at the machine and is unreachable an
hour later. Tell it not to sleep while it is on mains power - and leave the on-battery
settings alone, because a server unplugged on a shelf is just a flat battery.

  macOS      System Settings > Battery (or Energy Saver) > Options:
               "Prevent automatic sleeping on power adapter when the display is off" ON
               "Wake for network access" ON
             Or from a terminal:
               sudo pmset -c sleep 0
               sudo pmset -c disksleep 0
             Closing the lid sleeps a MacBook regardless. Leave it open, run it in
             clamshell mode (mains power AND an external display), or lift the rule with
             sudo pmset -b disablesleep 1 on a Mac that is always plugged in.

  Windows    Three separate settings, and missing one leaves the server dropping out:
               1. Settings > System > Power: sleep when plugged in -> Never
               2. Control Panel > Power Options > advanced settings > Sleep >
                  "Hibernate after" -> 0. Sleep and hibernate are different timers.
               3. Device Manager > Network adapters > your Wi-Fi adapter > Properties >
                  Power Management: untick "Allow the computer to turn off this device".
                  The PC stays awake and the server still vanishes without this one.
             On a laptop, also set "Choose what closing the lid does" to Do nothing.
             From an Administrator prompt:
               powercfg /change standby-timeout-ac 0
               powercfg /change hibernate-timeout-ac 0

  Linux/Pi   A Raspberry Pi never sleeps - one good reason it makes the best server.
             Do turn off Wi-Fi power saving, which makes discovery flaky:
               sudo iw dev wlan0 set power_save off
             Better still, give it a wired connection.
             On a Linux laptop:
               sudo systemctl mask sleep.target suspend.target hibernate.target
               and HandleLidSwitch=ignore in /etc/systemd/logind.conf

To check: leave the machine alone for an hour, then open http://<server-ip>:8080/ from a
different device. If it answers straight away you are done. If it answers only after you
touch the laptop, something is still sending it to sleep.

The full version of this, with the desktop-Linux and GNOME cases:
https://www.qspapps.com/fotoloka/server-setup.html#sleep


Where things end up
-------------------

                    macOS                              Windows                                 Linux / Pi
  Program           ~/Applications/FamilyPhotoBackup   %APPDATA%\FamilyPhotoBackup             /opt/fotoloka
  Photos            ~/Pictures/FamilyPhotoBackup       %USERPROFILE%\Pictures\...              ~/Pictures/FamilyPhotoBackup
  Settings          <program folder>/photobackup.properties
  Logs              ~/Library/Logs/FamilyPhotoBackup.log
                                                       %APPDATA%\FamilyPhotoBackup\server_log.log
                                                                                               journalctl -u fotoloka -f

If you passed a storage folder to the installer, the photos, the thumbnails and the
index database all live there instead - which is what makes backing up a single rsync.


Settings
--------

Everything is one file, photobackup.properties, in the program folder. It arrives fully
commented; uncomment what you want and restart the server.

  storage.root      where the library is kept
  server.password   a shared password every client must present
  tv.enabled        serve albums to a Smart TV browser at /tv/  (read the notes in the
                    file before turning this on - that page is deliberately not
                    password protected)

Restart after editing:

  macOS         launchctl unload ~/Library/LaunchAgents/com.qspapps.photobackup.plist
                launchctl load   ~/Library/LaunchAgents/com.qspapps.photobackup.plist
  Windows       run FamilyPhotoBackup.bat from your Startup folder again
  Linux / Pi    sudo systemctl restart fotoloka

The startup log names the file it read and what it resolved, so look there first if a
change does not seem to have applied.


Using it
--------

  From a browser   http://<server-ip>:8080/app/  - the complete client: browse, filter,
                   slideshow, upload, tag, albums, trash, profiles. Nothing to install.
  From Android     install the Fotoloka app; it finds the server on your Wi-Fi by itself.
  On a TV          http://<server-ip>:8080/tv/   - albums as a slideshow, driven by the
                   remote. Off until you set tv.enabled.

Full instructions: https://www.qspapps.com/fotoloka/


Importing from Google Photos
----------------------------

To migrate photos and videos from Google Photos, request an archive via Google
Takeout and save the resulting .zip files or extracted folders on the server machine.

Run the included extraction script:

  macOS / Linux:
    python3 extract_takeout_media.py <path-to-takeout-zips-or-folders> ~/Pictures/FamilyPhotoBackup/import/<your-name>

  Windows:
    python extract_takeout_media.py <path-to-takeout-zips-or-folders> %USERPROFILE%\Pictures\FamilyPhotoBackup\import\<your-name>

This extracts all photos and videos into your import directory, preserves album
structure and capture timestamps, converts Pixel motion photos (.mp) to .mp4, and
skips duplicates safely.

Once extracted, open the Android app, go to Sync Settings, and tap "Scan import folder"
(or let the server index them automatically).


Uninstall
---------

  macOS         ./macos/uninstall.sh
  Windows       windows\uninstall.bat
  Linux / Pi    sudo ./linux/uninstall.sh

These stop the server and remove the program. Your photos are left exactly where they
are - no uninstaller here deletes a photo.
