#!/bin/bash
#
# Fotoloka server uninstaller for macOS.
#
# Stops the background service and removes the program. Your photo library is left alone:
# it lives in ~/Pictures/FamilyPhotoBackup or on your external drive, not here.

set -e

echo "=== Fotoloka macOS Server Uninstaller ==="

PLIST_DEST="$HOME/Library/LaunchAgents/com.qspapps.photobackup.plist"
INSTALL_DIR="$HOME/Applications/FamilyPhotoBackup"

if [ -f "$PLIST_DEST" ]; then
    echo "Stopping the background service..."
    launchctl unload "$PLIST_DEST" 2>/dev/null || true
    echo "Removing launch agent: $PLIST_DEST"
    rm -f "$PLIST_DEST"
else
    echo "No launch agent found at $PLIST_DEST."
fi

if [ -d "$INSTALL_DIR" ]; then
    echo "Removing program files at: $INSTALL_DIR"
    rm -rf "$INSTALL_DIR"
fi

echo ""
echo "=== Uninstall complete ==="
echo "The server is stopped and will not start again at login."
echo "Your photos in ~/Pictures/FamilyPhotoBackup (or on your external drive) are untouched."
