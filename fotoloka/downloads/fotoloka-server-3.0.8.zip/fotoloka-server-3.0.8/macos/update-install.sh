#!/bin/bash
#
# Fotoloka server update & install launcher for macOS.
#
# Verifies Java 21+ prerequisite and starts the graphical Update-Install wizard.
#
# Usage:  ./update-install.sh [options]
#         ./update-install.sh --cli  (for headless / console mode)

set -e

echo "=== Fotoloka macOS Server Update & Installer ==="

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
BUNDLE_ROOT="$( cd "$SCRIPT_DIR/.." &> /dev/null && pwd )"

# 1. Java check: Require Java 21 or newer
if ! command -v java >/dev/null 2>&1; then
    echo "" >&2
    echo "==================================================================" >&2
    echo "[ERROR] Java runtime not found on your PATH." >&2
    echo "Fotoloka server requires Java 21 or newer to run." >&2
    echo "" >&2
    echo "Please download and install Java 21+ from one of the following sites:" >&2
    echo "  • Eclipse Temurin: https://adoptium.net/" >&2
    echo "  • Oracle Java:     https://www.oracle.com/java/technologies/downloads/" >&2
    echo "  • Homebrew (macOS): brew install --cask temurin@21" >&2
    echo "==================================================================" >&2
    echo "" >&2
    exit 1
fi

JAVA_VERSION_STR="$(java -version 2>&1 | head -n 1)"
JAVA_MAJOR="$(echo "$JAVA_VERSION_STR" | sed -E 's/.*version "([0-9]+).*/\1/')"
if [ "$JAVA_MAJOR" = "1" ]; then
    JAVA_MAJOR="$(echo "$JAVA_VERSION_STR" | sed -E 's/.*version "1\.([0-9]+).*/\1/')"
fi

if [ -z "$JAVA_MAJOR" ] || [ "$JAVA_MAJOR" -lt 21 ] 2>/dev/null; then
    echo "" >&2
    echo "==================================================================" >&2
    echo "[ERROR] Java $JAVA_MAJOR found ($JAVA_VERSION_STR)." >&2
    echo "Fotoloka server requires Java 21 or newer to run." >&2
    echo "" >&2
    echo "Please download and install Java 21+ from one of the following sites:" >&2
    echo "  • Eclipse Temurin: https://adoptium.net/" >&2
    echo "  • Oracle Java:     https://www.oracle.com/java/technologies/downloads/" >&2
    echo "  • Homebrew (macOS): brew install --cask temurin@21" >&2
    echo "==================================================================" >&2
    echo "" >&2
    exit 1
fi

# On macOS, verify /usr/bin/java stub for background launchd agent compatibility
if [ ! -x /usr/bin/java ] || ! /usr/bin/java -version >/dev/null 2>&1; then
    echo "[WARNING] /usr/bin/java does not resolve to a system runtime." >&2
    echo "          The background launchd agent requires a system-registered JDK (.pkg or brew)." >&2
fi

JAR_SOURCE="$BUNDLE_ROOT/photo-backup-server-all.jar"
if [ ! -f "$JAR_SOURCE" ]; then
    # Fallback if running from git repository checkout (server/dist/macos)
    REPO_ROOT="$BUNDLE_ROOT/.."
    JAR_SOURCE="$(ls "$REPO_ROOT/build/libs/photo-backup-server-"*"-all.jar" 2>/dev/null | head -n 1 || true)"
    if [ ! -f "$JAR_SOURCE" ] && [ -f "$REPO_ROOT/gradlew" ]; then
        echo "Building server shadow JAR from source..."
        (cd "$REPO_ROOT" && ./gradlew shadowJar)
        JAR_SOURCE="$(ls "$REPO_ROOT/build/libs/photo-backup-server-"*"-all.jar" 2>/dev/null | head -n 1 || true)"
    fi
fi

if [ ! -f "$JAR_SOURCE" ]; then
    echo "[ERROR] photo-backup-server-all.jar is missing from $BUNDLE_ROOT." >&2
    echo "        Unzip the entire download package or build with ./gradlew shadowJar." >&2
    exit 1
fi

# 2. Start update-install wizard
echo "Starting Fotoloka Update-Install Wizard..."
exec java -Dapple.awt.application.name="Fotoloka Installer" \
          -Dapple.laf.useScreenMenuBar=true \
          -jar "$JAR_SOURCE" --wizard --bundle-dir "$BUNDLE_ROOT" "$@"
