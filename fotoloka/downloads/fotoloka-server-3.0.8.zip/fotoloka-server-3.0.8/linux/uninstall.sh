#!/bin/bash
#
# Fotoloka server uninstaller for Linux.
#
# Stops and deregisters the service and removes the program. Your photo library is left
# alone: it lives under your storage folder, not in /opt/fotoloka.

set -e

echo "=== Fotoloka Linux Server Uninstaller ==="

if [ "$(id -u)" -ne 0 ]; then
    echo "[ERROR] Run this with sudo: sudo ./uninstall.sh" >&2
    exit 1
fi

SERVICE_NAME="fotoloka"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"
INSTALL_DIR="/opt/fotoloka"

if [ -f "$SERVICE_FILE" ]; then
    echo "Stopping and disabling the service..."
    systemctl stop "$SERVICE_NAME" 2>/dev/null || true
    systemctl disable "$SERVICE_NAME" 2>/dev/null || true
    rm -f "$SERVICE_FILE"
    systemctl daemon-reload
else
    echo "No service found at $SERVICE_FILE."
fi

if [ -d "$INSTALL_DIR" ]; then
    echo "Removing program files at: $INSTALL_DIR"
    rm -rf "$INSTALL_DIR"
fi

echo ""
echo "=== Uninstall complete ==="
echo "The server is stopped and will not start again at boot."
echo "Your photo library is untouched."
