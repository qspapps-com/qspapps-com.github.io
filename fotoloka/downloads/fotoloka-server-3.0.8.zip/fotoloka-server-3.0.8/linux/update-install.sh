#!/bin/bash
#
# Fotoloka server update & install launcher for Linux, including Raspberry Pi.
#
# Verifies Java 21+ prerequisite and starts the Update-Install wizard.
#
# Usage:  ./update-install.sh [options]
#         ./update-install.sh --cli  (for headless / console mode)

set -e

echo "=== Fotoloka Linux Server Update & Installer ==="

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
BUNDLE_ROOT="$( cd "$SCRIPT_DIR/.." &> /dev/null && pwd )"

# 1. Java check: Require Java 21 or newer
if ! command -v java >/dev/null 2>&1; then
    echo "" >&2
    echo "==================================================================" >&2
    echo "[ERROR] Java runtime not found on your PATH." >&2
    echo "Fotoloka server requires Java 21 or newer to run." >&2
    echo "" >&2
    echo "Please install Java 21+ using your package manager or download site:" >&2
    echo "  • Debian / Ubuntu / Raspberry Pi OS:" >&2
    echo "      sudo apt update && sudo apt install -y default-jre" >&2
    echo "  • Eclipse Temurin: https://adoptium.net/" >&2
    echo "  • Oracle Java:     https://www.oracle.com/java/technologies/downloads/" >&2
    echo "==================================================================" >&2
    echo "" >&2
    exit 1
fi

JAVA_VERSION_STR="$(java -version 2>&1 | head -n 1)"
JAVA_MAJOR="$(echo "$JAVA_VERSION_STR" | sed -E 's/.*version "([0-9]+).*/\1/')"
if [ "$JAVA_MAJOR" = "1" ]; then
    JAVA_MAJOR="$(echo "$JAVA_VERSION_STR" | sed -E 's/.*version "1\.([0-9]+).*/\1/')"
fi

if [ -z "$JAVA_MAJOR" ] || [ "$JAVA_MAJOR" -lt 21 ] 2>/dev/null; then
    echo "" >&2
    echo "==================================================================" >&2
    echo "[ERROR] Java $JAVA_MAJOR found ($JAVA_VERSION_STR)." >&2
    echo "Fotoloka server requires Java 21 or newer to run." >&2
    echo "" >&2
    echo "Please upgrade to Java 21+:" >&2
    echo "  • Debian / Ubuntu / Raspberry Pi OS:" >&2
    echo "      sudo apt update && sudo apt install -y default-jre" >&2
    echo "  • Eclipse Temurin: https://adoptium.net/" >&2
    echo "  • Oracle Java:     https://www.oracle.com/java/technologies/downloads/" >&2
    echo "==================================================================" >&2
    echo "" >&2
    exit 1
fi

JAR_SOURCE="$BUNDLE_ROOT/photo-backup-server-all.jar"
if [ ! -f "$JAR_SOURCE" ]; then
    # Fallback if running from git repository checkout (server/dist/linux)
    REPO_ROOT="$BUNDLE_ROOT/.."
    JAR_SOURCE="$(ls "$REPO_ROOT/build/libs/photo-backup-server-"*"-all.jar" 2>/dev/null | head -n 1 || true)"
    if [ ! -f "$JAR_SOURCE" ] && [ -f "$REPO_ROOT/gradlew" ]; then
        echo "Building server shadow JAR from source..."
        (cd "$REPO_ROOT" && ./gradlew shadowJar)
        JAR_SOURCE="$(ls "$REPO_ROOT/build/libs/photo-backup-server-"*"-all.jar" 2>/dev/null | head -n 1 || true)"
    fi
fi

if [ ! -f "$JAR_SOURCE" ]; then
    echo "[ERROR] photo-backup-server-all.jar is missing from $BUNDLE_ROOT." >&2
    echo "        Unpack the entire download package or build with ./gradlew shadowJar." >&2
    exit 1
fi

# 2. Start update-install wizard
echo "Starting Fotoloka Update-Install Wizard..."
exec java -jar "$JAR_SOURCE" --wizard --bundle-dir "$BUNDLE_ROOT" "$@"
